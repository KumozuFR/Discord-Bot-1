Features:

Customizable Messages
Advanced config
Support for any invite link
Automatic Leaderboard Panels
Remove Invite Roles on member leave
Add/Remove Bonus Invites
Blacklist users from leaderboard
Invite Verification


Commands:

Invites - See how many invites you have.
Invitetop - Show the top inviters in your guild.
InvitePanel - Send an automatic InviteLeaderboard to a channel. (This panel automatically updates showing the top 10 users)
InvitesHide - Hide a user from the leaderboard.
InvitesAdd - Add bonus invites to a user.
InvitesRemove - Remove bonus invites from a user.