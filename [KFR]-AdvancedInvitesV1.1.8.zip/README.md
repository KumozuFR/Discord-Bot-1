1. Drag the files into your corebot directory
AdvancedInvites.js -> Addons
59Utils.js -> Main Directory (Always update this file)
2. UPDATE 59Utils.js THIS IS IMPORTANT
3. Go to the directory ./commands/other & delete invites.js & invitetop.js, making a backup of these are recommended incase you decide to not use advancedInvites anymore. 
4. boot up your bot
